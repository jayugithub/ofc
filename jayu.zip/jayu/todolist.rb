class TodoList
  def initialize
    @tasks = []
  end

  def add_task(task)
    @tasks << task
  end

  def show_tasks
    puts "Tasks:"
    @tasks.each_with_index do |task, index|
      puts "#{index + 1}. #{task}"
    end
  end

  def remove_task(task_index)
    @tasks.delete_at(task_index - 1) if task_index.between?(1, @tasks.size)
  end
end

# Example usage:
todo_list = TodoList.new

todo_list.add_task("Buy groceries")
todo_list.add_task("Clean the house")
todo_list.add_task("Finish coding assignment")

todo_list.show_tasks

puts "Removing task at index 2"
todo_list.remove_task(2)

todo_list.show_tasks