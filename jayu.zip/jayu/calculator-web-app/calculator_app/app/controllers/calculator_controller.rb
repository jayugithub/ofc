require 'dentaku'

class CalculatorController < ApplicationController
  def index
    @operand1 = params[:operand1].to_f
    @operand2 = params[:operand2].to_f
    @operator = params[:operator]

    if @operand1.present? && @operand2.present? && @operator.present?
      @result = calculate_result(@operand1, @operand2, @operator)
    end
  end

  private

  def calculate_result(operand1, operand2, operator)
    case operator
    when '+'
      operand1 + operand2
    when '-'
      operand1 - operand2
    when '*'
      operand1 * operand2
    when '/'
      if operand2 != 0
        operand1 / operand2
      else
        'Error: Division by zero'
      end
    else
      'Error: Invalid operator'
    end
  end
end